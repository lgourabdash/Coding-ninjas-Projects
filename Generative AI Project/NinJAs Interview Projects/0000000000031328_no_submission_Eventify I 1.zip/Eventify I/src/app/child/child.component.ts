import { CommonModule } from '@angular/common';
import { Component, Input, SimpleChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';

interface Event {
  title: string;
  src: string,
  place: string;
  days: number;
}

@Component({
  selector: 'app-child',
  standalone: true,
  imports: [CommonModule, CommonModule, FormsModule],
  templateUrl: './child.component.html',
  styleUrl: './child.component.css'
})
export class ChildComponent {
  @Input() event: Event[] | null = null;
  
  isLoading = true;

  constructor() {
  }

  ngOnChanges(changes: SimpleChanges) {
    const eventDataChange = changes['event'];
    if (eventDataChange && !eventDataChange.firstChange) {
      this.isLoading = false;
    }
  }
  
  ngOnInit() {
    if (this.event === null) {
      this.isLoading = true;
    }
  }

}
