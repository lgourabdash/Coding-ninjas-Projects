import { Component, } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ChildComponent } from './child/child.component';

interface Event {
  title: string;
  place: string;
  src:string,
  days: number;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, ChildComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

  eventData!: Event[];

  constructor() {
    setTimeout(() => {
      this.eventData = [
        {
          title: 'Moon Landing',
          place: 'Space',
          src:'https://getbootstrap.com/docs/5.3/examples/features/unsplash-photo-1.jpg',
          days: 3
        },
        {
          title: 'Nature',
          place: 'Ajar',
          src:'https://getbootstrap.com/docs/5.3/examples/features/unsplash-photo-2.jpg',
          days: 5
        },
        {
          title: 'Endless Ocean',
          place: 'Indian Ocean',
          src:'https://getbootstrap.com/docs/5.3/examples/features/unsplash-photo-3.jpg',
          days: 1
        }
      ];
    }, 2000);
  }

}
